package com.fahclient

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

data class GuestAccount(
    val id: Long,
    var label: String,
    var uid: String,
    var nickname: String,
    var notes: String,
    var game: String
)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("fah_local_accounts", MODE_PRIVATE) }
    private val accounts = mutableListOf<GuestAccount>()
    private lateinit var list: LinearLayout
    private lateinit var count: TextView
    private val bg = Color.rgb(10, 14, 24)
    private val panel = Color.rgb(22, 30, 46)
    private val yellow = Color.rgb(255, 204, 0)
    private val white = Color.WHITE
    private val muted = Color.rgb(180, 190, 210)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadAccounts()
        render()
    }

    private fun render() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(24))
        }
        scroll.addView(page)
        val brand = TextView(this).apply {
            text = "FAH CLIENT"
            textSize = 29f
            setTextColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(brand)
        page.addView(TextView(this).apply {
            text = "FREE FIRE • GUEST ACCOUNT MANAGER"
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(4), 0, dp(18))
        })
        val hero = TextView(this).apply {
            text = "จัดการบัญชีในเครื่องเดียว\nบันทึกข้อมูล • เปิดเกม • สำรองรายการ"
            textSize = 17f
            setTextColor(white)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        page.addView(hero, matchWrap())
        count = TextView(this).apply {
            setTextColor(yellow); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(18), 0, dp(8))
        }
        page.addView(count)
        val add = button("+ เพิ่มบัญชี", yellow, Color.BLACK) { showAccountDialog(null) }
        page.addView(add, matchWrap())
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("เปิด Free Fire", panel, white) { launchGame(false) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(5) })
        row.addView(button("เปิด FF MAX", panel, white) { launchGame(true) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(5) })
        page.addView(row, matchWrap())
        val exportRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        exportRow.addView(button("ส่งออก JSON", panel, white) { exportJson() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(5) })
        exportRow.addView(button("นำเข้า JSON", panel, white) { importJson() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { leftMargin = dp(5) })
        page.addView(exportRow, matchWrap())
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(list, matchWrap())
        page.addView(TextView(this).apply {
            text = "หมายเหตุ: แอปนี้จัดเก็บข้อมูลที่คุณกรอกและเปิดเกมได้เท่านั้น ไม่สามารถสร้าง/กู้/สลับบัญชี Guest ภายในเกมโดยตรง และไม่อ่านข้อมูลส่วนตัวของเกม"
            setTextColor(muted); textSize = 12f; setPadding(0, dp(20), 0, 0)
        })
        setContentView(scroll)
        refreshList()
    }

    private fun refreshList() {
        count.text = "บัญชีที่บันทึกไว้: ${accounts.size}"
        list.removeAllViews()
        if (accounts.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "ยังไม่มีบัญชี\nกด “+ เพิ่มบัญชี” เพื่อบันทึก UID / ชื่อ / หมายเหตุ"
                setTextColor(muted); textSize = 14f; gravity = Gravity.CENTER
                setPadding(dp(12), dp(28), dp(12), dp(28))
            })
        }
        accounts.forEach { account ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setBackgroundColor(panel)
            }
            val title = TextView(this).apply {
                text = account.label
                textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(yellow)
            }
            card.addView(title)
            card.addView(info("ชื่อในเกม: ${account.nickname.ifBlank { "—" }}"))
            card.addView(info("UID: ${account.uid.ifBlank { "—" }}"))
            if (account.notes.isNotBlank()) card.addView(info("หมายเหตุ: ${account.notes}"))
            card.addView(info("ประเภท: ${if (account.game == "max") "Free Fire MAX" else "Free Fire"}"))
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(button("แก้ไข", Color.rgb(38,49,70), white) { showAccountDialog(account) }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { rightMargin = dp(4) })
            actions.addView(button("เปิดเกม", yellow, Color.BLACK) { launchGame(account.game == "max") }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
            actions.addView(button("ลบ", Color.rgb(90,35,42), white) {
                android.app.AlertDialog.Builder(this).setTitle("ลบบัญชีนี้?")
                    .setMessage("ลบเฉพาะรายการที่บันทึกใน FAH CLIENT ไม่ได้ลบบัญชีในเกม")
                    .setNegativeButton("ยกเลิก", null)
                    .setPositiveButton("ลบ") { _, _ -> accounts.removeAll { it.id == account.id }; saveAccounts(); refreshList() }.show()
            }, LinearLayout.LayoutParams(0, dp(42), 0.75f).apply { leftMargin = dp(4) })
            card.addView(actions)
            val lp = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
            list.addView(card, lp)
        }
    }

    private fun info(s: String) = TextView(this).apply {
        text = s; textSize = 13f; setTextColor(muted); setPadding(0, dp(3), 0, dp(3))
    }

    private fun showAccountDialog(existing: GuestAccount?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        fun field(hint: String, value: String = ""): EditText {
            return EditText(this).apply {
                this.hint = hint; setText(value); textSize = 15f; setSingleLine(hint != "หมายเหตุ")
                setTextColor(white); setHintTextColor(muted)
            }.also { box.addView(it, matchWrap()) }
        }
        val label = field("ชื่อเรียกบัญชี", existing?.label ?: "")
        val nickname = field("ชื่อผู้เล่นในเกม", existing?.nickname ?: "")
        val uid = field("UID (ถ้าทราบ)", existing?.uid ?: "")
        val notes = field("หมายเหตุ", existing?.notes ?: "")
        val game = Spinner(this)
        game.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Free Fire", "Free Fire MAX"))
        game.setSelection(if (existing?.game == "max") 1 else 0)
        box.addView(game, matchWrap())
        val dialog = android.app.AlertDialog.Builder(this).setTitle(if (existing == null) "เพิ่มบัญชี" else "แก้ไขบัญชี")
            .setView(box).setNegativeButton("ยกเลิก", null)
            .setPositiveButton("บันทึก", null).create()
        dialog.setOnShowListener {
            dialog.getButton(-1).setOnClickListener {
                if (label.text.toString().trim().isEmpty()) {
                    label.error = "กรุณาตั้งชื่อเรียกบัญชี"; return@setOnClickListener
                }
                val newAccount = GuestAccount(
                    existing?.id ?: System.currentTimeMillis(),
                    label.text.toString().trim(), uid.text.toString().trim(),
                    nickname.text.toString().trim(), notes.text.toString().trim(),
                    if (game.selectedItemPosition == 1) "max" else "normal"
                )
                if (existing == null) accounts.add(newAccount) else {
                    val i = accounts.indexOfFirst { it.id == existing.id }
                    if (i >= 0) accounts[i] = newAccount
                }
                saveAccounts(); refreshList(); dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun launchGame(max: Boolean) {
        val packages = if (max) listOf("com.dts.freefiremax", "com.dts.freefireth") else listOf("com.dts.freefireth", "com.dts.freefiremax")
        for (pkg in packages) {
            val intent = packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) { startActivity(intent); return }
        }
        android.app.AlertDialog.Builder(this).setTitle("ไม่พบเกม")
            .setMessage("ติดตั้ง Free Fire หรือ Free Fire MAX จากแหล่งทางการก่อน แล้วลองอีกครั้ง")
            .setPositiveButton("ตกลง", null).show()
    }

    private fun exportJson() {
        val arr = JSONArray()
        accounts.forEach { a ->
            arr.put(JSONObject().put("id", a.id).put("label", a.label).put("uid", a.uid)
                .put("nickname", a.nickname).put("notes", a.notes).put("game", a.game))
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "fah-client-accounts.json")
        }
        exportPending = arr.toString(2)
        startActivityForResult(intent, 101)
    }

    private var exportPending: String = ""
    private fun importJson() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
        }
        startActivityForResult(intent, 102)
    }

    @Deprecated("Deprecated in Android API but supported for this starter")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        try {
            if (requestCode == 101) {
                contentResolver.openOutputStream(data.data!!)?.bufferedWriter()?.use { it.write(exportPending) }
                Toast.makeText(this, "ส่งออกไฟล์สำเร็จ", Toast.LENGTH_LONG).show()
            } else if (requestCode == 102) {
                val raw = contentResolver.openInputStream(data.data!!)?.bufferedReader()?.use { it.readText() } ?: ""
                val arr = JSONArray(raw)
                var imported = 0
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = System.currentTimeMillis() + i
                    accounts.add(GuestAccount(id, o.optString("label", "Guest"), o.optString("uid"),
                        o.optString("nickname"), o.optString("notes"), o.optString("game", "normal")))
                    imported++
                }
                saveAccounts(); refreshList()
                Toast.makeText(this, "นำเข้า $imported รายการ", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "อ่านไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadAccounts() {
        try {
            val arr = JSONArray(prefs.getString("accounts", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                accounts.add(GuestAccount(o.optLong("id", System.currentTimeMillis() + i),
                    o.optString("label", "Guest"), o.optString("uid"), o.optString("nickname"),
                    o.optString("notes"), o.optString("game", "normal")))
            }
        } catch (_: Exception) { }
    }

    private fun saveAccounts() {
        val arr = JSONArray()
        accounts.forEach { a ->
            arr.put(JSONObject().put("id", a.id).put("label", a.label).put("uid", a.uid)
                .put("nickname", a.nickname).put("notes", a.notes).put("game", a.game))
        }
        prefs.edit().putString("accounts", arr.toString()).apply()
    }

    private fun button(text: String, color: Int, textColor: Int, action: () -> Unit) =
        Button(this).apply {
            this.text = text; setTextColor(textColor); setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
            textSize = 13f; isAllCaps = false; setOnClickListener { action() }
        }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
